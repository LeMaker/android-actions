// Simple worker used to provoke WebGL context release bugs on Chrome

postMessage("Hello World");
close();